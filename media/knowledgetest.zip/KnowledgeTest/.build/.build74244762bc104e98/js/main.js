//Initialize function
var init = function () {
	// TODO:: Do your initialization job
	parseJsonQuestions('animalQuestions','animal', animalAnswers);
	parseJsonQuestions('birdQuestions','bird',birdAnswers);
	parseJsonQuestions('plantQuestions','plant',plantAnswers);
};
$(document).ready(init);

var animalAnswers = new Array();
var birdAnswers = new Array();
var plantAnswers = new Array();
var alertMsgId ='';
var pageTimerId = '';
var pageId ='';

/**
 * Stores the answers in an array and evaluates(calculates the score) of the right answers submitted by the user in the particular form
 * @param form  : receives the unique id of the particular form that is submitted by the user
 *@param answers: 
 */
function evaluateAnswers(form, answers) {
	var questions = new Array();
	var score = 0;

	var formName = form.name;
	formName = formName.substr(0, formName.length - 1);
	var $timer = $('#timer-for-' + formName);

	for(var i = 0; i < 10; i++) {
		questions[i] = form[formName + (i + 1)];
	}

	$timer.html('').countdown('destroy');
	pageId = formName;

//	evaluate answers
	for (var i=0; i < questions.length; i++) {
		var currQuestionObject = questions[i];
		for (var j=0; j<currQuestionObject.length; j++){
			if (currQuestionObject[j].checked && currQuestionObject[j].value === answers[i]){
				score++; break;
			}
		}
	}
	refreshQuizPage(pageId);
	showScore(score);

}

/**
 * This function refreshes the individual quiz
 * page by making all the radio buttons unchecked when the page is loaded freshly
 */
refreshQuizPage = function(id) {
	for(var i =1; i<=10;i++){
		for(var j=1;j<5;j++) {
			$('#'+id+i+'-choice-'+j).attr("checked",false).checkboxradio("refresh");
		}
	}
}

/**
 * This function updates the score to the result page
 */
showScore = function(score) {
	var msg="";
	if(score === 0) {
		msg ="<label>Your score is "+score+"</label>";
	} else {
		msg = "<h2>Congratulations</h2>"
			+"<label>Your score is "+score+"</label>";
	}	
	document.getElementById('score').innerHTML=msg;	
}


/**
 * Sets the timer as count down for 120 sec
 * @param timerId  : id of the div element in which timer value will be displayed
 * @param messageId: id of the div elelment in which the message "Few more seconds left" is displayed when the user falls short of time
 * @param page:  id of the particular form that needs to be refreshed once the timer is timed out
 */

function startTimer(timerId, messageId,pgId) {
	var timer_message = document.getElementById(messageId);	
	timer_message.innerHTML="";
	alertMsgId = timer_message;
	pageTimerId = timerId;
	pageId = pgId;
	$('#'+timerId).countdown({
		until : 120,
		format : 'S',
		compact : true,
		onTick : trackTime,
		onExpiry : goToHomePage
	});
}

function trackTime(periods) {
	if(periods[6]===30){
		alertMsgId.innerHTML = "You are running out of time!"
	}
}

/**
 * Parses the json file and renders the json objects to the html file on loading of the application on emulator/device
 * @param keyObject - key to identify each page attributes in json
 * @param: form  : receives the jsonobject,unique id of the particular form that is submitted by the user and the selected answer of the user
 * @param:ansArr - Array to which the answers parsed from json will be pushed, which
 * is used later for evaluating user submitted answers
 */

parseJsonQuestions = function(keyObject, formid, ansArr) {

	var htmlQuestions = '';

	$.getJSON("questions.json", function(data) {
		for ( var i = 0; i < data.questions[keyObject].length; i++) {
			var text = data.questions[keyObject][i].Question;
			htmlQuestions += '<fieldset data-role="controlgroup">';
			var question = data.questions[keyObject][i].Question;
			var name = data.questions[keyObject][i].name;
			var ids = data.questions[keyObject][i].ids;
			var values = data.questions[keyObject][i].values;
			var labels = data.questions[keyObject][i].labels;
			var answer = data.questions[keyObject][i].Answer;
			ansArr.push(answer);
			htmlQuestions += '<legend>' + question + '</legend>';
			for ( var j = 0; j < labels.length; j++) {
				htmlQuestions += '<input type="radio" name="' + name + '" id="'
				+ ids[j] + '" value="' + values[j] + '"/>';
				htmlQuestions += '<label for="' + ids[j]
				+ '" style="height:30px;">' + labels[j] + '</label>';
			}
			htmlQuestions += '</fieldset>';
		}
		document.getElementById(formid).innerHTML = htmlQuestions;
	});

};

function quit()
{
	var currentApp = tizen.application.getCurrentApplication();
	currentApp.exit();
}

/**
 * Functions to handle click events of the button
 */

$(document).on('click', '#animalBtn', function(e) {
	startTimer('timer-for-animal', 'message-div-animal', 'animal');
});

$(document).on('click', '#plantBtn', function(e) {
	startTimer('timer-for-plant', 'message-div-plant', 'plant');
});

$(document).on('click', '#birdBtn', function(e) {
	startTimer('timer-for-bird', 'message-div-bird', 'bird');	
});

$(document).on('click', '#animalPgSbmt', function(e) {
	evaluateAnswers(document.forms['animals'],animalAnswers);
});

$(document).on('click', '#plantPgSbmt', function(e) {
	evaluateAnswers(document.forms['plants'],plantAnswers);
});

$(document).on('click', '#birdPgSbmt', function(e) {
	evaluateAnswers(document.forms['birds'],birdAnswers);
});

$(document).on('click', '#btn1', function(e) {
	quit();
});

function goToHomePage(){
	alert("\n\n\n                   Times up!\n                      Sorry...")
	refreshQuizPage(pageId);
	$('#'+pageTimerId).countdown('destroy');
	$.mobile.changePage("#menu", {
		transition : "slideup"
	});
}
